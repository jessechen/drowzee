import{l as o,a as r}from"../chunks/1oys23Sj.js";export{o as load_css,r as start};
